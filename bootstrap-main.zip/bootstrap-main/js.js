// 1 Переменные

var name = 'Aleksandr';
const lastName = 'Panchenko';
let age = 26;

name = 'Alex';
age = 27


console.log(name, age);